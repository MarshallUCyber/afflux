#ifndef RABINKARP
#define RABINKARP
#endif
